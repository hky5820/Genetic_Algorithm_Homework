#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <time.h>

struct gene {
	int *genotype;
	int metric;
};

void init_square_Edge(std::ifstream &input, std::vector<std::vector<int>> &square_Edge, const int count_Edge) {
	int startVertex, targetVertex, weight;

	for (int i = 0; i < count_Edge; i++) {
		input >> startVertex; input >> targetVertex; input >> weight;
		startVertex -= 1; targetVertex -= 1;
		square_Edge[startVertex][targetVertex] = weight;
		square_Edge[targetVertex][startVertex] = weight;
	}
}

void child_Metric_Calculation(int count_Vertex, int *child, std::vector<std::vector<int>> &square_Edge) {
	for (int currentIndex = 0; currentIndex < count_Vertex - 1; currentIndex++) {
		for (int otherIndex = currentIndex + 1; otherIndex < count_Vertex; otherIndex++) {
			if (child[currentIndex] != child[otherIndex]) {
				if (square_Edge[currentIndex][otherIndex] != 0) {
					child[count_Vertex] += square_Edge[currentIndex][otherIndex];
				}
			}
		}
	}
}

int main(int argc, char **argv) {
	
	std::ifstream input("maxcut.in");

	if (input.is_open()) {
		int count_Vertex, count_Edge;

		input >> count_Vertex;
		input >> count_Edge;

		int *arr = new int[count_Vertex];

		std::vector<std::vector<int>> square_Edge(count_Vertex, std::vector<int>(count_Vertex, 0));
		init_square_Edge(input, square_Edge, count_Edge);

		std::ifstream result("maxcut.out");

		int temp = 0;
		if (result.is_open()) {
			while (!result.eof()) {
				result >> temp;
				arr[temp-1] = 1;
			}
		}

		child_Metric_Calculation(count_Vertex, arr, square_Edge);
		printf("metric = %d\n", arr[count_Vertex]);
	} 

	return 0;
}