#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <time.h>
#include <string.h>

#define solutionCount 50
#define timeLimit 175

const int number_New_Child = (int)(solutionCount * 0.5);
const int upper_Roulette = (int)(solutionCount *0.3);
const int index_Top = (int)(solutionCount * 0.3);

struct gene {
	int *genotype;
	int metric;
};

typedef std::vector<gene> GENE;

void init_vertexSquare(std::ifstream &input, std::vector<std::vector<int>> &vertexSquare, const int count_Edge);
void init_solutions(GENE &solutions, int count_Vertex);
void one_Solution_Metric_Calculation(int solutionIndex, int count_Vertex, GENE &solutions, std::vector<std::vector<int>> &vertexSquare);
double fitness_Calculation(std::vector<double> *fitness, GENE &solutions, int costMin, int costMax, double &sumOfFitness);
void child_Metric_Calculation(int count_Vertex, int *child, std::vector<std::vector<int>> &vertexSquare);
void selection(std::vector<double> &fitness, double sumOfFitness, int &selectedIndex1, int &selectedIndex2);
void mix_Arr(int count_Vertex, int *arr);
void local_Search_Solution(int *index_Arr, gene &solution, int count_Vertex, std::vector<std::vector<int>> vertexSquare);
void local_Search_Child(int *index_Arr, int *child, int count_Vertex, std::vector<std::vector<int>> vertexSquare);

int count_Print = 0;
int how_Many_Reset = 0;
int bestCut = 0;
int is_stop = 0; 

int main(int argc, char **argv) {

	int time_Start, time_Current;
	time_Start = (int)time(NULL);
	time_Current = (int)time(NULL);
	srand((unsigned int)time(NULL));

	std::ifstream input("random_500.txt");
	std::ofstream output("maxcut.out");
	
	if (input.is_open()) {
		int count_Vertex, count_Edge;

		input >> count_Vertex;
		input >> count_Edge;

		std::vector<std::vector<int>> vertexSquare(count_Vertex, std::vector<int>(count_Vertex, 0));
		GENE solutions;
		init_vertexSquare(input, vertexSquare, count_Edge);
		init_solutions(solutions, count_Vertex);

		int *index_Arr = new int[count_Vertex - 1];
		for (int i = 0; i < count_Vertex-1; i++) {
			index_Arr[i] = i + 1;
		}

		for (int i = 0; i < solutionCount; i++) {
			local_Search_Solution(index_Arr, solutions[i], count_Vertex, vertexSquare);
		}

		int *child = new int[count_Vertex + 1]; // VertexCount + Metric
		int **child_Group = new int*[number_New_Child]; 
		for (int i = 0; i < number_New_Child; i++) {
			child_Group[i] = new int[count_Vertex + 2]; // VertexCount + Metric + Index_Parent
			memset(child_Group[i], 0, sizeof(int)*(count_Vertex + 2));
		}
		
		for (int solutionIndex = 0; solutionIndex < solutionCount; solutionIndex++) {
			one_Solution_Metric_Calculation(solutionIndex, count_Vertex, solutions, vertexSquare);
		}

		int is_Best_Occur = 0;
		int *best_Solution = new int[count_Vertex];
		memset(best_Solution, 0, sizeof(int)*count_Vertex);

		// Child ���� ����
		do {
			std::sort(solutions.begin(), solutions.end(), [](const gene& lhs, const gene& rhs) {
				return lhs.metric > rhs.metric;
			});

			int costMax = solutions[0].metric; 
			int costMin = solutions[solutionCount - 1].metric;

			int sum_Metric = 0; 
			for (int i = 0; i < solutionCount; i++) sum_Metric += solutions[i].metric; 
			int average = sum_Metric / solutionCount;

			double sumOfFitness = 0;
			std::vector<double> fitness(upper_Roulette, 0);
			fitness_Calculation(&fitness, solutions, costMin, costMax, sumOfFitness);

			if (bestCut < costMax) {
				is_Best_Occur = 1;
				bestCut = costMax;
				for (int i = 0; i < count_Vertex; i++) {
					best_Solution[i] = solutions[0].genotype[i];
				}
			}			
			if (count_Print % 50 == 0) printf("max= %d min= %d avg= %d upper= %d best= %d time= %d\n", costMax, costMin, average,solutions[index_Top].metric, bestCut, time(NULL) - time_Start);

			int index_Below_Worst = solutionCount - 1;
			if ((solutions[0].metric - solutions[index_Top].metric) == 0) {
				how_Many_Reset++;

				int probaility = (int)rand() % 5 + 3;
		
				for (int ind = 0; ind < solutionCount; ind++) {
					for (int j = 1; j < count_Vertex; j++) {
						int temp_Probability = (int)rand() % 10;
	
						if (temp_Probability < probaility) {
							solutions[ind].genotype[j] = 1;
						}
						else {
							solutions[ind].genotype[j] = 0;
						}
					}
					solutions[ind].metric = 0;
				}

				for (int i = 0; i < solutionCount; i++) {
					local_Search_Solution(index_Arr, solutions[i], count_Vertex, vertexSquare);
				}

				for (int solutionIndex = 0; solutionIndex < solutionCount; solutionIndex++) {
					one_Solution_Metric_Calculation(solutionIndex, count_Vertex, solutions, vertexSquare);
				}
				printf("max= %d min= %d avg= %d upper= %d best= %d time= %d Reset= %d\n", costMax, costMin, average, solutions[index_Top].metric, bestCut, time(NULL) - time_Start, how_Many_Reset);

			}
			else if ((solutions[0].metric - solutions[index_Top].metric) != 0 ) {
				for (int i = 0; i < number_New_Child; i++) {

					memset(child, 0, sizeof(int)*(count_Vertex + 1));

					/*Selection*/
					int selectedIndex1; int selectedIndex2;
					selection(fitness, sumOfFitness, selectedIndex1, selectedIndex2);

					int parentCost1 = solutions[selectedIndex1].metric; 
					int parentCost2 = solutions[selectedIndex2].metric;
					int index_Better; int index_Worse;

					if (parentCost1 >= parentCost2) {
						index_Better = selectedIndex1;
						index_Worse = selectedIndex2;
					}
					else {
						index_Better = selectedIndex2;
						index_Worse = selectedIndex1;
					}

					/*Crossover*/
					double crossover_Probability = 0.6;
					for (int i = 1; i < count_Vertex; i++) {
						double random = (double)rand() / RAND_MAX;
						if (random < crossover_Probability) {
							child[i] = solutions[index_Better].genotype[i];
						}
						else {
							child[i] = solutions[index_Worse].genotype[i];
						}
					}

					/*Mutation*/
					double timeDifference = (double)time(NULL) - (double)time_Start;
					double probability = 0.1;
					for (int i = 1; i < count_Vertex; i++) {
						double random = (double)rand() / RAND_MAX;

						if (random < probability) {
							child[i] = abs(child[i] - 1);
						}
					}

					local_Search_Child(index_Arr, child, count_Vertex, vertexSquare);

					/*Child Metric Calculation*/
					child[count_Vertex] = 0;
					child_Metric_Calculation(count_Vertex, child, vertexSquare);
					child_Group[i][count_Vertex] = child[count_Vertex];

					for (int j = 0; j < count_Vertex; j++) {
						child_Group[i][j] = child[j];
					}

					child_Group[i][count_Vertex + 1] = index_Below_Worst;
					index_Below_Worst--;
				}

				/*Replace*/
				for (int i = 0; i < number_New_Child; i++) {
					for (int j = 0; j < count_Vertex; j++) {
						solutions[child_Group[i][count_Vertex + 1]].genotype[j] = child_Group[i][j];
					}
					solutions[child_Group[i][count_Vertex + 1]].metric = child_Group[i][count_Vertex];
				}
			}

			for (int i = 0; i < number_New_Child; i++) {
				memset(child_Group[i], 0, sizeof(int)*(count_Vertex + 2));
			}

			count_Print++;
			time_Current = time(NULL);
		} while (is_stop = (time_Current - time_Start) < timeLimit);

		printf("count = %d\n", count_Print);
		if (is_Best_Occur) {
			for (int i = 0; i < count_Vertex; i++) {
				if (best_Solution[i] == 0) {
					output << i + 1 << " ";
				}
			}
			output << "\n";
		}
		else {
			for (int i = 0; i < count_Vertex; i++) {
				if (solutions[0].genotype[i] == 0) {
					output << i + 1 << " ";
				}
			}
			output << "\n";
		}
	} // is_open
   	return 0;
}

void init_vertexSquare(std::ifstream &input, std::vector<std::vector<int>> &vertexSquare, const int count_Edge) {
	int startVertex, targetVertex, weight;

	for (int i = 0; i < count_Edge; i++) {
		input >> startVertex; input >> targetVertex; input >> weight;
		startVertex -= 1; targetVertex -= 1;
		vertexSquare[startVertex][targetVertex] = weight;
		vertexSquare[targetVertex][startVertex] = weight;
	}
}
void init_solutions(GENE &solutions, int count_Vertex) {
	int probaility = (int)rand() % 5 + 3;		
	
	for (int i = 0; i < solutionCount; i++) {
		gene newGene;
		newGene.genotype = new int[count_Vertex + 1];
		newGene.genotype[0] = 0;
		for (int j = 1; j < count_Vertex + 1; j++) {
			int temp_Probability = (int)rand() % 10;
			if (temp_Probability < probaility) {
				newGene.genotype[j] = 1;
			}
			else {
				newGene.genotype[j] = 0;
			}
		}
		newGene.metric = 0;
		solutions.push_back(newGene);
	}
}
void one_Solution_Metric_Calculation(int solutionIndex, int count_Vertex, GENE &solutions, std::vector<std::vector<int>> &vertexSquare) {
	for (int currentIndex = 0; currentIndex < count_Vertex - 1; currentIndex++) {
		for (int otherIndex = currentIndex + 1; otherIndex < count_Vertex; otherIndex++) {
			if (solutions[solutionIndex].genotype[currentIndex] != solutions[solutionIndex].genotype[otherIndex]) { // ���� �ڱ�� �ٸ� �׷쿡 ���Ѵٸ�,
				solutions[solutionIndex].metric += vertexSquare[currentIndex][otherIndex]; // ����Ǿ� �ִٸ�, Metric �� �����ش�.
			}
		}
	}
}
double fitness_Calculation(std::vector<double> *fitness, GENE &solutions, int costMin, int costMax, double &sumOfFitness) {
	double k = 3;

	for (double i = 0; i < upper_Roulette; i++) {
		(*fitness)[i] = ((double)solutions[i].metric - (double)costMin) + ((double)costMax - (double)costMin) / (k - 1.0);
		sumOfFitness += (*fitness)[i];
	}

	return sumOfFitness;
}
void child_Metric_Calculation(int count_Vertex, int *child, std::vector<std::vector<int>> &vertexSquare) {
	for (int currentIndex = 0; currentIndex < count_Vertex - 1; currentIndex++) {
		for (int otherIndex = currentIndex + 1; otherIndex < count_Vertex; otherIndex++) {
			if (child[currentIndex] != child[otherIndex]) {
				if (vertexSquare[currentIndex][otherIndex] != 0) {
					child[count_Vertex] += vertexSquare[currentIndex][otherIndex];
				}
			}
		}
	}
}
void selection(std::vector<double> &fitness, double sumOfFitness, int &selectedIndex1, int &selectedIndex2) {
	double point = (double)rand() / RAND_MAX * sumOfFitness;
	double sum = 0;
	for (int i = 0; i < upper_Roulette; i++) {
		sum = sum + fitness[i];
		if (point <= sum) {
			selectedIndex1 = i;
			break;
		}
	}

	do {
		point = (double)rand() / RAND_MAX * sumOfFitness;
		sum = 0;
		for (int i = 0; i < upper_Roulette; i++) {
			sum = sum + fitness[i];
			if (point <= sum) {
				selectedIndex2 = i;
				break;
			}
		}
	} while (selectedIndex1 == selectedIndex2);
}
void mix_Arr(int count_Vertex, int *arr) {
	int num_Mix1, num_Mix2;

	for (int i = 0; i < 1000; i++) {
		num_Mix1 = rand() % (count_Vertex - 1);
		num_Mix2 = rand() % (count_Vertex - 1);

		int temp;
		temp = arr[num_Mix1];
		arr[num_Mix1] = arr[num_Mix2];
		arr[num_Mix2] = temp;
	}
}
void local_Search_Solution(int *index_Arr, gene &solution, int count_Vertex, std::vector<std::vector<int>> vertexSquare) {

	mix_Arr(count_Vertex, index_Arr);

	int improved = true;

	while (improved) {

		improved = false;

		for (int ind_permutation = 0; ind_permutation < count_Vertex - 1; ind_permutation++) {
			int sum = 0;

			for (int ind_solution = 0; ind_solution < count_Vertex; ind_solution++) {

				if (solution.genotype[ind_solution] != solution.genotype[index_Arr[ind_permutation]]){
					sum -= vertexSquare[index_Arr[ind_permutation]][ind_solution];
				}
				else {
					sum += vertexSquare[index_Arr[ind_permutation]][ind_solution];
				}
			}

			if (sum > 0) {
				solution.genotype[index_Arr[ind_permutation]] = abs(1 - solution.genotype[index_Arr[ind_permutation]]);
				improved = true;
			}
		}
	}
}

void local_Search_Child(int *index_Arr, int *child, int count_Vertex, std::vector<std::vector<int>> vertexSquare) {

	mix_Arr(count_Vertex, index_Arr);

	int improved = true;

	while (improved) {

		improved = false;

		for (int ind_permutation = 0; ind_permutation < count_Vertex - 1; ind_permutation++) {
			int sum = 0;

			for (int ind_solution = 0; ind_solution < count_Vertex; ind_solution++) {

				if (child[ind_solution] != child[index_Arr[ind_permutation]]) {
					sum -= vertexSquare[index_Arr[ind_permutation]][ind_solution];
				}
				else {
					sum += vertexSquare[index_Arr[ind_permutation]][ind_solution];
				}
			}

			if (sum > 0) {
				child[index_Arr[ind_permutation]] = abs(1 - child[index_Arr[ind_permutation]]);
				improved = true;
			}
		}
	}
}
