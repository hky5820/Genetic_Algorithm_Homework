#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <time.h>
#include <string.h>

#define solutionCount 1

struct gene {
	int *genotype;
	int metric;
};

typedef std::vector<gene> GENE;

void init_vertexSquare(std::ifstream &input, std::vector<std::vector<int>> &vertexSquare, const int count_Edge);
void one_Solution_Metric_Calculation(int solutionIndex, int count_Vertex, GENE &solutions, std::vector<std::vector<int>> &vertexSquare);
void mix_Arr(int count_Vertex, int *arr);
void local_Search_Solution(int *index_Arr, gene &solution, int count_Vertex, std::vector<std::vector<int>> vertexSquare);

int bestCut = INT_MIN;

int main(int argc, char **argv) {
	int time_Start, time_Current;
	time_Start = (int)time(NULL);
	time_Current = (int)time(NULL);
	srand((unsigned int)time(NULL));

	std::ifstream input("planar_800.txt");
	//std::ifstream input(argv[1]);
	std::ofstream output("maxcut.out");

	int how_Many_Local_Optimization_Occur = 960;

	if (input.is_open()) {
		int count_Vertex, count_Edge;

		input >> count_Vertex;
		input >> count_Edge;

		std::vector<std::vector<int>> vertexSquare(count_Vertex, std::vector<int>(count_Vertex, 0));
		init_vertexSquare(input, vertexSquare, count_Edge);

		GENE solutions;
		int probaility = (int)rand() % 5 + 3;
		for (int i = 0; i < solutionCount; i++) {
			gene newGene;
			newGene.genotype = new int[count_Vertex + 1];
			newGene.genotype[0] = 0;
			for (int j = 1; j < count_Vertex + 1; j++) {
				int temp_Probability = (int)rand() % 10;
				if (temp_Probability < probaility) {
					newGene.genotype[j] = 1;
				}
				else {
					newGene.genotype[j] = 0;
				}
			}
			newGene.metric = 0;
			solutions.push_back(newGene);
		}

		int *index_Arr = new int[count_Vertex - 1];
		for (int i = 0; i < count_Vertex - 1; i++) {
			index_Arr[i] = i + 1;
		}

		for (int i = 0; i < how_Many_Local_Optimization_Occur; i++) {

			probaility = (int)rand() % 5 + 3;

			for (int ind = 0; ind < solutionCount; ind++) {
				for (int j = 1; j < count_Vertex; j++) {
					int temp_Probability = (int)rand() % 10;
					if (temp_Probability < probaility) {
						solutions[ind].genotype[j] = 1;
					}
					else {
						solutions[ind].genotype[j] = 0;
					}
				}
				solutions[ind].metric = 0;
			}

			local_Search_Solution(index_Arr, solutions[0], count_Vertex, vertexSquare);

			for (int solutionIndex = 0; solutionIndex < solutionCount; solutionIndex++) {
				one_Solution_Metric_Calculation(solutionIndex, count_Vertex, solutions, vertexSquare);
			}

			if (solutions[0].metric > bestCut) {
				bestCut = solutions[0].metric;
			}
		}
		printf("best = %d\n", bestCut);
	}
	return 0;
}














void init_vertexSquare(std::ifstream &input, std::vector<std::vector<int>> &vertexSquare, const int count_Edge) {
	int startVertex, targetVertex, weight;

	for (int i = 0; i < count_Edge; i++) {
		input >> startVertex; input >> targetVertex; input >> weight;
		startVertex -= 1; targetVertex -= 1;
		vertexSquare[startVertex][targetVertex] = weight;
		vertexSquare[targetVertex][startVertex] = weight;
	}
}

void one_Solution_Metric_Calculation(int solutionIndex, int count_Vertex, GENE &solutions, std::vector<std::vector<int>> &vertexSquare) {
	for (int currentIndex = 0; currentIndex < count_Vertex - 1; currentIndex++) {
		for (int otherIndex = currentIndex + 1; otherIndex < count_Vertex; otherIndex++) {
			if (solutions[solutionIndex].genotype[currentIndex] != solutions[solutionIndex].genotype[otherIndex]) { // ���� �ڱ�� �ٸ� �׷쿡 ���Ѵٸ�,
				solutions[solutionIndex].metric += vertexSquare[currentIndex][otherIndex]; // ����Ǿ� �ִٸ�, Metric �� �����ش�.
			}
		}
	}
}


void mix_Arr(int count_Vertex, int *arr) {
	int num_Mix1, num_Mix2;

	for (int i = 0; i < 1000; i++) {
		num_Mix1 = rand() % (count_Vertex - 1);
		num_Mix2 = rand() % (count_Vertex - 1);

		int temp;
		temp = arr[num_Mix1];
		arr[num_Mix1] = arr[num_Mix2];
		arr[num_Mix2] = temp;
	}
}
void local_Search_Solution(int *index_Arr, gene &solution, int count_Vertex, std::vector<std::vector<int>> vertexSquare) {

	mix_Arr(count_Vertex, index_Arr);

	int improved = true;

	while (improved) {

		improved = false;

		for (int ind_permutation = 0; ind_permutation < count_Vertex - 1; ind_permutation++) {
			int sum = 0;

			for (int ind_solution = 0; ind_solution < count_Vertex; ind_solution++) {

				if (solution.genotype[ind_solution] != solution.genotype[index_Arr[ind_permutation]]) {
					sum -= vertexSquare[index_Arr[ind_permutation]][ind_solution];
				}
				else {
					sum += vertexSquare[index_Arr[ind_permutation]][ind_solution];
				}
			}

			if (sum > 0) {
				solution.genotype[index_Arr[ind_permutation]] = abs(1 - solution.genotype[index_Arr[ind_permutation]]);
				improved = true;
			}
		}
	}
}