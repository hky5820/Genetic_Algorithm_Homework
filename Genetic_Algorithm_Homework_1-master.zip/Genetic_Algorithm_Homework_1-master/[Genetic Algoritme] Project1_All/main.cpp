#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <time.h>

#define solutionCount 100
#define timeLimit 175

const int number_New_Child = (int)(solutionCount * 0.3);
const int index_Top_70 = (int)(solutionCount * 0.7);

struct gene {
	int *genotype;
	int metric;
};

void init_vertexSquare(std::ifstream &input, std::vector<std::vector<int>> &vertexSquare, const int count_Edge) {
	int startVertex, targetVertex, weight;

	for (int i = 0; i < count_Edge; i++) {
		input >> startVertex; input >> targetVertex; input >> weight;
		startVertex -= 1; targetVertex -= 1;
		vertexSquare[startVertex][targetVertex] = weight;
		vertexSquare[targetVertex][startVertex] = weight;
	}
}

void init_solutions(std::vector<gene> &solutions, int count_Vertex) {
	for (int i = 0; i < solutionCount; i++) {
		gene newGene;
		newGene.genotype = new int[count_Vertex];
		newGene.genotype[0] = 0;
		for (int j = 1; j < count_Vertex; j++) {
			newGene.genotype[j] = rand() % 2;
		}
		newGene.metric = 0;
		solutions.push_back(newGene);
	}
}

void one_Solution_Metric_Calculation(int solutionIndex, int count_Vertex, std::vector<gene> &solutions, std::vector<std::vector<int>> &vertexSquare) {
	for (int currentIndex = 0; currentIndex < count_Vertex - 1; currentIndex++) {
		for (int otherIndex = currentIndex + 1; otherIndex < count_Vertex; otherIndex++) {
			if (solutions[solutionIndex].genotype[currentIndex] != solutions[solutionIndex].genotype[otherIndex]) { // ���� �ڱ�� �ٸ� �׷쿡 ���Ѵٸ�,
				solutions[solutionIndex].metric += vertexSquare[currentIndex][otherIndex]; // ����Ǿ� �ִٸ�, Metric �� �����ش�.
			}
		}
	}
}

double fitness_Calculation(std::vector<double> *fitness, std::vector<gene> &solutions,int costMin, int costMax, double &sumOfFitness) {
	double k = 3;

	for (double i = 0; i < solutionCount; i++) {
		(*fitness)[i] = ((double)solutions[i].metric - (double)costMin) + ((double)costMax - (double)costMin) / (k - 1.0);
		sumOfFitness += (*fitness)[i];
	}

	return sumOfFitness;
}

void child_Metric_Calculation(int count_Vertex, int *child, std::vector<std::vector<int>> &vertexSquare) {
	for (int currentIndex = 0; currentIndex < count_Vertex - 1; currentIndex++) {
		for (int otherIndex = currentIndex + 1; otherIndex < count_Vertex; otherIndex++) {
			if (child[currentIndex] != child[otherIndex]) {
				if (vertexSquare[currentIndex][otherIndex] != 0) {
					child[count_Vertex] += vertexSquare[currentIndex][otherIndex];
				}
			}
		}
	}
}

void selection(std::vector<double> &fitness, double sumOfFitness, int &selectedIndex1, int &selectedIndex2) {
	double point = (double)rand() / RAND_MAX * sumOfFitness;
	double sum = 0;
	for (int i = 0; i < solutionCount; i++) {
		sum = sum + fitness[i];
		if (point <= sum) {
			selectedIndex1 = i;
			break;
		}
	}

	do {
		point = (double)rand() / RAND_MAX * sumOfFitness;
		sum = 0;
		for (int i = 0; i < solutionCount; i++) {
			sum = sum + fitness[i];
			if (point <= sum) {
				selectedIndex2 = i;
				break;
			}
		}
	} while (selectedIndex1 == selectedIndex2);
}

int count_Print = 0;
int is_stop = 0; int bestCut = 0;

int main(int argc, char **argv) {

	int time_Start, time_Current;
	time_Start = (int)time(NULL);
	time_Current = (int)time(NULL);
	srand((unsigned int)time(NULL));

	std::ifstream input("weighted_chimera_297.txt");
	std::ofstream output("maxcut.out");
	
	if (input.is_open()) {
		int count_Vertex, count_Edge;

		input >> count_Vertex;
		input >> count_Edge;

		std::vector<std::vector<int>> vertexSquare(count_Vertex, std::vector<int>(count_Vertex, 0));
		init_vertexSquare(input, vertexSquare, count_Edge);

		std::vector<gene> solutions;
		init_solutions(solutions, count_Vertex);

		for (int solutionIndex = 0; solutionIndex < solutionCount; solutionIndex++) {
			one_Solution_Metric_Calculation(solutionIndex, count_Vertex, solutions, vertexSquare);
		}

		int *child = new int[count_Vertex + 1]; // VertexCount + Metric
		int **child_Group = new int*[number_New_Child]; 
		for (int i = 0; i < number_New_Child; i++) {
			child_Group[i] = new int[count_Vertex + 2]; // VertexCount + Metric + Index_Parent
			for(int j = 0; j < count_Vertex +2; j++){
				child_Group[i][j] = 0;
			}	
		}
		
		int is_Best_Occur = 0;
		int *best_Solution = new int[count_Vertex];
		
		for(int i = 0; i < count_Vertex; i++){
			best_Solution[i]= 0;	
		}

		// Child ���� ����
		do {
			std::sort(solutions.begin(), solutions.end(), [](const gene& lhs, const gene& rhs) {
				return lhs.metric > rhs.metric;
			});

			int costMax = solutions[0].metric; 
			int costMin = solutions[solutionCount - 1].metric;

			int sum_Metric = 0; 
			for (int i = 0; i < solutionCount; i++) sum_Metric += solutions[i].metric; 
			int average = sum_Metric / solutionCount;

			double sumOfFitness = 0;
			std::vector<double> fitness(solutionCount, 0);
			fitness_Calculation(&fitness, solutions, costMin, costMax, sumOfFitness);

			if (bestCut < costMax) {
				is_Best_Occur = 1;
				bestCut = costMax;
				for (int i = 0; i < count_Vertex; i++) {
					best_Solution[i] = solutions[0].genotype[i];
				}
			}			
			if (count_Print % 300 == 0) printf("costmax = %d, costmin = %d, average = %d, best = %d, time = %d, cost_upper_30 = %d\n", costMax, costMin, average, bestCut, time(NULL) - time_Start, solutions[index_Top_70].metric);
			int index_Below_Worst = solutionCount - 1;
			if ((solutions[0].metric - solutions[index_Top_70].metric) == 0) {

				for (int ind = 0; ind < solutionCount; ind++) {
					for (int j = 1; j < count_Vertex; j++) {
						solutions[ind].genotype[j] = rand() % 2;
					}
					solutions[ind].metric = 0;
				}

				for (int solutionIndex = 0; solutionIndex < solutionCount; solutionIndex++) {
					one_Solution_Metric_Calculation(solutionIndex, count_Vertex, solutions, vertexSquare);
				}
			}
			else if ((solutions[0].metric - solutions[index_Top_70].metric) != 0 ) {
				for (int i = 0; i < number_New_Child; i++) {
					for (int i = 0; i < count_Vertex + 1; i++) {
						child[i] = 0;
					}

					/*Selection*/
					int selectedIndex1; int selectedIndex2;
					selection(fitness, sumOfFitness, selectedIndex1, selectedIndex2);

					int parentCost1 = solutions[selectedIndex1].metric; 
					int parentCost2 = solutions[selectedIndex2].metric;
					int index_Better; int index_Worse;

					if (parentCost1 >= parentCost2) {
						index_Better = selectedIndex1;
						index_Worse = selectedIndex2;
					}
					else {
						index_Better = selectedIndex2;
						index_Worse = selectedIndex1;
					}

					/*Crossover*/
					double crossover_Probability = 0.6;
					for (int i = 1; i < count_Vertex; i++) {
						double random = (double)rand() / RAND_MAX;
						if (random < crossover_Probability) {
							child[i] = solutions[index_Better].genotype[i];
						}
						else {
							child[i] = solutions[index_Worse].genotype[i];
						}
					}

					/*Mutation*/
					double timeDifference = (double)time(NULL) - (double)time_Start;
					double probability = 0.005;
					for (int i = 1; i < count_Vertex; i++) {
						double random = (double)rand() / RAND_MAX;

						if (random < probability) {
							child[i] = abs(child[i] - 1);
						}
					}

					/*Child Metric Calculation*/
					child[count_Vertex] = 0;
					child_Metric_Calculation(count_Vertex, child, vertexSquare);
					child_Group[i][count_Vertex] = child[count_Vertex];

					for (int j = 0; j < count_Vertex; j++) {
						child_Group[i][j] = child[j];
					}

					/*Choose Replace Index*/
					if (child[count_Vertex] < parentCost1 && child[count_Vertex] < parentCost2) {
						child_Group[i][count_Vertex + 1] = index_Below_Worst;
						index_Below_Worst--;
					}
					else {
						child_Group[i][count_Vertex + 1] = index_Worse;
					}
				} // �ڽ� 25�� ����

				/*Replace*/
				for (int i = 0; i < number_New_Child; i++) {
					for (int j = 0; j < count_Vertex; j++) {
						solutions[child_Group[i][count_Vertex + 1]].genotype[j] = child_Group[i][j];
					}
					solutions[child_Group[i][count_Vertex + 1]].metric = child_Group[i][count_Vertex];
				}
			}

			for (int i = 0; i < number_New_Child; i++) {
				for(int j = 0; j < count_Vertex+2; j++){
					child_Group[i][j]  = 0; 
				}
			}

			count_Print++;
			time_Current = time(NULL);
		} while (is_stop = (time_Current - time_Start) < timeLimit);

		if (is_Best_Occur) {
			for (int i = 0; i < count_Vertex; i++) {
				if (best_Solution[i] == 0) {
					output << i + 1 << " ";
				}
			}
			output << "\n";
		}
		else {
			for (int i = 0; i < count_Vertex; i++) {
				if (solutions[0].genotype[i] == 0) {
					output << i + 1 << " ";
				}
			}
			output << "\n";
		}
	} // is_open

	return 0;
}
